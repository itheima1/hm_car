import numpy as np
from maplib import Point
from matplotlib.patches import Rectangle
import matplotlib.pyplot as plt
class Astar:
    def __init__(self,map,startPoint,endPoint):
        self.map = map
        # 记录已经处理过的点
        self.close_set = []
        # 待处理的点
        self.open_set = []

        self.startPoint = startPoint
        self.endPoint = endPoint

    def move_cost(self,curr):
        # 距离起点的距离
        x_dis = abs(curr.x - self.startPoint.x)
        y_dis = abs(curr.y - self.startPoint.y)
        # Distance to start point
        dist_start = x_dis + y_dis + (np.sqrt(2) - 2) * min(x_dis, y_dis)
        # 距离终点的距离
        x_dis = abs(curr.x - self.endPoint.x)
        y_dis = abs(curr.y - self.endPoint.y)
        # Distance to end point
        dist_end = x_dis + y_dis + (np.sqrt(2) - 2) * min(x_dis, y_dis)
        # 距离之和
        return dist_start + dist_end

    def isValidPoint(self,x,y):
        """
            判断点是否为一个有效的点
        """
        # 判断是否超过地图边界
        if x <0 or y < 0:
            return False;
        if x >= self.map.size or y >= self.map.size:
            return False
        # 判断是否为障碍物
        return not self.map.isObstacle(x,y)

    def selectPointFromOpenSet(self):
        """
        返回一个移动代价最小的点，从open_set中选择一个
        """
        index = 0;
        min_cost = 10000;
        for i,p in enumerate(self.open_set):
            cost = p.cost;
            if cost < min_cost:
                min_cost = cost
                index = i

        return index;

    def isInCloseSet(self,x,y):
        for p in self.close_set:
            if x == p.x and y == p.y:
                return True
        return False

    def isInOpenSet(self,x,y):
        for p in self.open_set:
            if x == p.x and y == p.y:
                return True
        return False

    def processPoint(self,x,y,parent):
        """处理点"""
        # 1. 判断当前点是否为有效点
        if not self.isValidPoint(x,y):
            return ;
        # 2. 判断当前点是否已经处理过了
        if self.isInCloseSet(x,y):
            return
        # 3. 若当前没有处理被处理，放到待处理点集中
        p = Point(x,y);
        if not self.isInOpenSet(x,y):
            p.parent = parent
            p.cost = self.move_cost(p)

            self.open_set.append(p);

    def buildPath(self,point):
        # 保存路径
        path = []

        while True:
            # 直到反向找到起点为止
            path.insert(0,point);
            # 判断是否为起点
            if point.x == self.startPoint.x and point.y == self.startPoint.y:
                break;
            else:
                point = point.parent


        return path;

    def run(self,ax):

        # 1. 从起点开始处理,设置起点代价为0
        self.startPoint.cost = 0;
        self.open_set.append(self.startPoint);

        # 2. 在循环中对open_set中的点进行响应的处理
        while True:
            # 3. 从open_set中取点 移动代价最小的点
            index = self.selectPointFromOpenSet();

            # 4. 取出当前的点
            curr = self.open_set[index];

            # 为了显示动态遍历的过程
            rec = Rectangle((curr.x, curr.y), width=1, height=1, color="pink");
            ax.add_patch(rec)
            plt.pause(0.0000001);
            # 5. 判断当前的点是否为终点
            # 6.若为终点
            if curr.x == self.endPoint.x and curr.y == self.endPoint.y:
                print("已经找到了终点",curr.x,curr.y)
                path = self.buildPath(curr);
                # 绘制路径
                for p in path:
                    rec = Rectangle((p.x, p.y), width=1, height=1, color="green");
                    ax.add_patch(rec)
                break;
            else:
                #print(curr.x,curr.y,len(self.open_set))
                # 7. 若不为终点
                # 将当前点放到close_set中
                self.close_set.append(curr)
                # 将当前的点从open_set删除掉
                del self.open_set[index];

                # 8. 继续去处理当前点的8邻域位置
                x,y = curr.x,curr.y
                self.processPoint(x-1,y+1,curr)
                self.processPoint(x,y+1,curr)
                self.processPoint(x+1,y+1,curr)

                self.processPoint(x - 1, y, curr)
                self.processPoint(x + 1, y, curr)

                self.processPoint(x - 1, y - 1, curr)
                self.processPoint(x, y - 1, curr)
                self.processPoint(x + 1, y - 1, curr)
