import sys
class Point:
    """
    地图中的每一个点
    """
    def __init__(self,x,y):
        self.x = x
        self.y = y
        # 定义一个变量用于记录
        self.parent = -1
        # 定义变量，用于记录当前点的移动代价
        self.cost = sys.maxsize

    def __repr__(self):
        return "(x={}，y={})".format(self.x,self.y);

class Map:
    """创建地图"""
    def __init__(self,size=36):
        """地图初始化"""
        # 定义地图的尺寸
        self.size = size;
        # 定义列表记录所有的障碍物
        self.obstacle_points=[]

    def generate_obstacle(self):

        # 生成障碍物 左边的墙
        for i in range(self.size):
            self.obstacle_points.append(Point(0,i))

        # 右边的墙
        for i in range(self.size):
            self.obstacle_points.append(Point(i, self.size - 1))

        # 下边的墙
        for i in range(self.size):
            self.obstacle_points.append(Point(i, 0))

        # 上边的墙
        for i in range(self.size):
            self.obstacle_points.append(Point(self.size - 1, i))

        # 左边的障碍物
        for y in range(self.size):
            if y <= 18 or y >= 30:
                self.obstacle_points.append(Point(9, y))

        # 中间的障碍物
        for y in range(9, 27):
            self.obstacle_points.append(Point(18, y))

        # 右边的障碍物
        for y in range(self.size):
            if y <= 6 or y >= 30 or (y >= 15 and y <= 21):
                self.obstacle_points.append(Point(27, y))

    def isObstacle(self,x,y):
        """判断是否是障碍物的位置"""
        for p in self.obstacle_points:
            if x == p.x and y == p.y:
                return True

        return False