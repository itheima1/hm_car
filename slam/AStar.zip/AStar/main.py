
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Rectangle
from maplib import Map,Point
"""
模拟SLAM：
    建图： matplotlib
    导航： A星导航算法
"""
# 构建地图对象
map = Map(36)
map.generate_obstacle()

# 绘图
plt.figure(figsize=(5,5))

# 初始化
plt.ion()
ax = plt.gca();
ax.set_xlim([0,36])
ax.set_ylim([0,36])

for row in range(map.size):
    for col in range(map.size):
        if map.isObstacle(row,col):
            # 绘制黑色方块
            rec = Rectangle((row, col), width=1, height=1, color="gray");
            ax.add_patch(rec)

        else:
            # 绘制白色的方块
            rec = Rectangle((row, col), width=1, height=1,edgecolor="gray",facecolor="white");
            ax.add_patch(rec)

# 起始点
startPoint = Point(1,1)
# 目标点
endPoint = Point(map.size-2,map.size-2)
# 显示起始点和结束点
rec = Rectangle((startPoint.x,startPoint.y),width=1,height=1,color="r");
ax.add_patch(rec)

rec = Rectangle((endPoint.x,endPoint.y),width=1,height=1,color="green");
ax.add_patch(rec)

from a_star import Astar
astar = Astar(map,startPoint,endPoint);
astar.run(ax);

plt.show()
plt.pause(0)
